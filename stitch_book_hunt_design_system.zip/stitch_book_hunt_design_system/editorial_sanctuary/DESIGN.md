---
name: Editorial Sanctuary
colors:
  surface: '#fff8f6'
  surface-dim: '#e6d7d2'
  surface-bright: '#fff8f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff1ec'
  surface-container: '#faebe6'
  surface-container-high: '#f4e5e0'
  surface-container-highest: '#eedfda'
  on-surface: '#211a17'
  on-surface-variant: '#574145'
  inverse-surface: '#372f2b'
  inverse-on-surface: '#fdeee8'
  outline: '#8b7074'
  outline-variant: '#debfc3'
  surface-tint: '#ae2a53'
  primary: '#971643'
  on-primary: '#ffffff'
  primary-container: '#b8325a'
  on-primary-container: '#ffdce1'
  inverse-primary: '#ffb1c0'
  secondary: '#7e5261'
  on-secondary: '#ffffff'
  secondary-container: '#ffc5d7'
  on-secondary-container: '#7b4f5e'
  tertiary: '#6b424f'
  on-tertiary: '#ffffff'
  tertiary-container: '#865967'
  on-tertiary-container: '#ffdbe4'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffd9de'
  primary-fixed-dim: '#ffb1c0'
  on-primary-fixed: '#3f0016'
  on-primary-fixed-variant: '#8d0b3c'
  secondary-fixed: '#ffd9e3'
  secondary-fixed-dim: '#f0b7c9'
  on-secondary-fixed: '#31101e'
  on-secondary-fixed-variant: '#643a49'
  tertiary-fixed: '#ffd9e3'
  tertiary-fixed-dim: '#efb8c8'
  on-tertiary-fixed: '#31101d'
  on-tertiary-fixed-variant: '#633b48'
  background: '#fff8f6'
  on-background: '#211a17'
  surface-variant: '#eedfda'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 44px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-tablet: 2rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style
The design system establishes a private, tactile, and deeply intellectual reading companion. It rejects the hyperactive gamification, noisy social feeds, and commercial clutter of mainstream reading trackers in favor of a secluded personal study or private library archive. The emotional resonance is calm, contemplative, and enduring—an interface that honors the craft of literature and personal reflection.

The visual style blends modern editorial minimalism with subtle tactile qualities. It features generous typographic breathing room, fine-gauge structural linework reminiscent of archival ledger books, and warm, paper-inspired foundational tones. Rather than cold stark whites, the surfaces evoke heavy-stock cream paper, balanced by deep literary carbon ink and an authoritative, sophisticated vintage raspberry accent.

## Colors
The palette is built around an archival reading aesthetic:

- **Primary (`#B8325A`)**: An authoritative, mature deep raspberry-rose used strictly for key calls to action, active indicators, and high-priority states. It achieves over 4.5:1 contrast against warm parchment surfaces. Bubblegum and fluorescent pinks are strictly avoided.
- **Secondary (`#7A4E5D`)**: A muted, dusty plum-slate that provides grounded sophistication for secondary metrics, structural highlights, and tag categories.
- **Tertiary (`#DDA7B7`)**: A soft antique rose used for subtle interactive states, delicate divider rules, and hover fills.
- **Neutral Primary Ink (`#1E1917` & `#2D2522`)**: Deep charcoal-espresso text offering near-black contrast while preserving paper-and-ink warmth.
- **Neutral Secondary Ink (`#6B5E57`)**: A warm umber tone reserved for secondary labels, publication metadata, and timestamps.
- **Surfaces**: Canvas default uses Parchment White (`#FAF8F5`), container surfaces use Soft Vellum (`#F4EFEA`), and elevated sheet elements use Pressed Flax (`#ECE4DC`).
- **Surface Accents**: Soft Rose Tint (`#FCE7ED`) is used exclusively for badge containers and non-text highlighting. Pale pink text against light surfaces is prohibited across all UI states.

## Typography
The typographic system pairs the literary authority of **Playfair Display** with the clear ergonomics of **Plus Jakarta Sans**. 

- **Headlines & Editorial Titles**: Rendered in Playfair Display. Used for book titles, section milestones, reading log quotes, and primary screen banners. Tighter letter spacing on display variants creates a polished bookplate feel.
- **Interface & Prose Text**: Rendered in Plus Jakarta Sans. Sets all catalog metadata, author attributions, note excerpts, form fields, and navigation chrome.
- **Rhythm**: All line heights align strictly to an 4px/8px vertical baseline grid. Long-form reading notes must cap line lengths between 60 and 72 characters to maintain optimal reading cadence.

## Layout & Spacing
The layout follows a fluid-responsive column grid system built on an 8px base rhythm:

- **Desktop (1024px and above)**: 12-column layout with max content width constrained to `1200px` for catalog views and `760px` for single-book reading logs. Margins are `3rem` (`48px`) with `1.5rem` (`24px`) gutters.
- **Tablet (768px - 1023px)**: 8-column layout with `2rem` (`32px`) margins and `1.5rem` (`24px`) gutters.
- **Mobile (320px - 767px)**: 4-column layout with `1.25rem` (`20px`) margins and `1rem` (`16px`) gutters.

Component padding and gap tokens (`space-*`) maintain proportional balance:
- `space-xs` (4px): Fine badge gaps and micro-alignments.
- `space-sm` (8px): Icon-to-label spacing, compact metadata rows.
- `space-md` (16px): Card internal padding, form row spacing.
- `space-lg` (24px): Inter-card margins, list section headers.
- `space-xl` (40px): Section transitions and view headers.

## Elevation & Depth
Elevation is expressed through tonal bookbinding layers and warm paper shadows rather than clinical digital blurs:

- **Base Layer**: Canvas surface `#FAF8F5`.
- **Level 1 (Cards, Ledger Rows)**: Surface `#FFFFFF` or `#F4EFEA`, framed by a fine `1px solid #E6DDD4` border, paired with an ambient tinted shadow: `0 2px 8px -2px rgba(45, 37, 34, 0.04)`.
- **Level 2 (Popovers, Sticky Headers, Flyouts)**: Surface `#FFFFFF`, border `1px solid #D8CFC5`, shadow `0 8px 24px -4px rgba(45, 37, 34, 0.08)`.
- **Level 3 (Modals, Detail Sheets)**: Surface `#FAF8F5`, border `1px solid #D8CFC5`, shadow `0 20px 40px -8px rgba(45, 37, 34, 0.12)`.
- **Tactile State**: Avoid harsh drop shadows; prioritize the interaction of crisp border tints (`#E6DDD4`) against parchment backgrounds to mimic book covers resting on a wooden desk.

## Shapes
The shape language uses moderate, tailored curves that reflect bound book edges, bookplates, and warm stationery:

- Base radius (`0.5rem` / `8px`): Inputs, primary buttons, dropdown triggers, and status chips.
- Large radius (`1rem` / `16px`): Book cards, collection panels, note containers, and slide-in drawers.
- Extra-large radius (`1.5rem` / `24px`): Dialog surfaces and featured showcase containers.
- Circular / Pill: Reserved exclusively for reading status tags (e.g., "Reading", "Finished") and icon button baselines to distinguish them from actionable structural cards.

## Components

### Buttons
- **Primary**: Background `#B8325A`, text `#FFFFFF`, radius `8px`, min height `44px`. Active state shifts to `#992245` with a subtle `scale(0.98)` depression. Focus ring: `2px solid #B8325A` with `2px` offset.
- **Secondary / Outlined**: Background transparent, border `1px solid #E6DDD4`, text `#2D2522`. Hover background `#F4EFEA`.
- **Ghost**: Background transparent, text `#6B5E57`. Hover text `#1E1917`, background `#ECE4DC`.

### Chips & Tags
- **Reading Status Badges**: Background `#FCE7ED`, text `#B8325A`, border `1px solid #F5C6D3`, radius `9999px`. Label font `label-sm`.
- **Genre & Taxonomy Chips**: Background `#F4EFEA`, border `1px solid #E6DDD4`, text `#6B5E57`, radius `6px`.

### Lists & Book Logs
- Structured with alternating or continuous thin dividers (`1px solid #E6DDD4`).
- List items feature hover state transitions to `#FAF8F5` with active touch targets constrained to minimum `44px` height.

### Checkboxes & Radio Controls
- Base: `20x20px` square (`4px` radius for checkbox, fully rounded for radio) with `1.5px solid #6B5E57`.
- Selected: Background `#B8325A`, border `#B8325A`, icon stroke `#FFFFFF` (white check or center pip).

### Input Fields & Search
- Background `#FFFFFF`, border `1px solid #E6DDD4`, radius `8px`, padding `10px 14px`.
- Placeholder text in `#A3968E`.
- Focus state: Border `#B8325A`, box-shadow `0 0 0 1px #B8325A`.

### Cards & Book Containers
- Book Cover Placements: Crisp `4px` rounded corners with an inner inset border `1px solid rgba(0,0,0,0.08)` to simulate cover spine edge depth.
- Card Container: Background `#FAF8F5` or `#FFFFFF`, border `1px solid #E6DDD4`, padding `space-md` (`16px`).

### Quote & Excerpt Blocks
- Left border `3px solid #B8325A`, background `#F4EFEA`, padding `16px 20px`, body text in Playfair Display italic.

### Icons
- Clean, refined linework with uniform `1.75px` stroke, rounded caps and joins. Base size `20x20px` inside minimum `44x44px` interactive touch boundaries.